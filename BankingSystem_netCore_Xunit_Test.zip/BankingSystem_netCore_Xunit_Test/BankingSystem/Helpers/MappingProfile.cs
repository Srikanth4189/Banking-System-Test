﻿using AutoMapper;
using BankingSystem.Dtos;
using BankingSystem.Entities.TestDb;
namespace BankingSystem.Helpers
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Users, UserDto.User>();
            CreateMap<UserDto.User, Users>();
        }
    }
}
