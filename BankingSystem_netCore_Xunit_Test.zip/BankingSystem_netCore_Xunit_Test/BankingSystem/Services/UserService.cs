﻿using AutoMapper;
using BankingSystem.Dtos;
using BankingSystem.Entities.TestDb;

namespace BankingSystem.Services
{
    public interface IUserService
    {
        UserDto.User GetUser(int id);

        UserDto.User AddUser(UserDto.User user);

        UserDto.User DeleteUser(int id);
        UserDto.User WithdrawAmount(int id, UserDto.User user);
        UserDto.User DepositAmount(int id, UserDto.User user);

        bool AccountBalanceLimit(int id);

        bool CheckIfWindrawAmountIsGreaterThan90Percent(int id, float Amount);

        bool CheckDepositLimit(float Amount);
    }
    public class UserService : IUserService
    {

        private TestDbContext _testDbContext;

        private IMapper _mapper;

        public UserService(TestDbContext testDbContext, IMapper mapper)
        {
            _testDbContext = testDbContext;
            _mapper = mapper;
        }

        public UserDto.User AddUser(UserDto.User user)
        {
            try
            {
                Users users = _mapper.Map<Users>(user);

                _testDbContext.Users.Add(users);
                _testDbContext.SaveChanges();

                return _mapper.Map<UserDto.User>(users);
            }
            catch (Exception exp)
            {
                return null;
            }
        }

        public UserDto.User WithdrawAmount(int id, UserDto.User user)
        {
            try
            {
                Users users = _testDbContext.Users.Where(w => w.Id == id).FirstOrDefault();
                if (users == null)
                    return null;


                if (AccountBalanceLimit(id) == true && CheckIfWindrawAmountIsGreaterThan90Percent(id, user.AccountBalance) )
                {
                    users.AccountBalance = users.AccountBalance - user.AccountBalance;
                    _testDbContext.Users.Update(users);
                    _testDbContext.SaveChanges();
                }

                return _mapper.Map<UserDto.User>(users);
            }
            catch (Exception exp)
            {
                return null;
            }
        }

        public UserDto.User DepositAmount(int id, UserDto.User user)
        {
            try
            {
                Users users = _testDbContext.Users.Where(w => w.Id == id).FirstOrDefault();
                if (users == null)
                    return null;

                if (AccountBalanceLimit(id) == true  && CheckDepositLimit(user.AccountBalance))
                { 
                 users.AccountBalance = users.AccountBalance + user.AccountBalance ;
                _testDbContext.Users.Update(users);
                _testDbContext.SaveChanges();
                }


                return _mapper.Map<UserDto.User>(users);
            }
            catch (Exception exp)
            {
                return null;
            }
        }
        public UserDto.User DeleteUser(int id)
        {
            Users users = _testDbContext.Users.Where(w => w.Id == id).FirstOrDefault();

            if (users == null)
                return null;

            _testDbContext.Users.Remove(users);
            _testDbContext.SaveChanges();

            return _mapper.Map<UserDto.User>(users);
        }

        public UserDto.User GetUser(int id)
        {
            Users users = _testDbContext.Users.Where(w => w.Id == id).FirstOrDefault();

            return _mapper.Map<UserDto.User>(users);
        }

        public bool AccountBalanceLimit(int id)
        {
            //bool IsUserHasvalidBalaceFlag;
            int IsUserHasvalidBalace = _testDbContext.Users.Where(w => w.Id == id && w.AccountBalance < 100).Count();

            return IsUserHasvalidBalace > 0 ? true : false ;
        }
        public bool CheckIfWindrawAmountIsGreaterThan90Percent(int id, float Amount)
        {
            //bool IsUserHasvalidBalaceFlag;
            Users users = _testDbContext.Users.Where(w => w.Id == id).FirstOrDefault();

            float AmountBalance = users.AccountBalance;
            double result = ((double)AmountBalance / 100) * 90;

            return result > Amount ? true : false;
        }

        public bool CheckDepositLimit(float Amount)
        {
            return Amount > 10000 ? true : false;
        }

    }
}
