﻿using BankingSystem.Controllers;
using BankingSystem.Dtos;
using BankingSystem.Services;
using BankingSystemTest.Fixture;
using BankingSystemTest.Theory;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Xunit;

namespace BankingSystemTest
{
    public class UserServiceTest : IClassFixture<UserServiceFixture>
    {
        private UserService _userService;
        /**
 * xUnit constructor runs before each test. 
 */
        public UserServiceTest(UserServiceFixture fixture)
        {
            _userService = fixture.userService;
        }

        [Theory]
        [InlineData(685349)]
        public void AccountBalanceLimit_WithTestData_ThenOk_Test(int id)
        {
            var ExpectedValue = false;
            var result = _userService.AccountBalanceLimit(id);

            Assert.Equal(ExpectedValue, result);
        }

        [Theory]
        [InlineData(0)]
        public void AccountBalanceLimit_WithNonUser_ThenBadRequest_Test(int id)
        {
            var ExpectedValue = false;
            var result = _userService.AccountBalanceLimit(id);

            Assert.Equal(ExpectedValue, result);
        }

        [Theory]
        [InlineData(685349, 1000)]
        public void CheckIfWindrawAmountIsGreaterThan90Percent_WithTestData_ThenOk_Test(int id, float amount)
        {
            var ExpectedValue = true;
            var result = _userService.CheckIfWindrawAmountIsGreaterThan90Percent(id, amount);

            Assert.Equal(ExpectedValue, result);
        }

    }
}
