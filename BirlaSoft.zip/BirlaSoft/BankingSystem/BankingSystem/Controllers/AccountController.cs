﻿using BankingSystem.Dtos;
using BankingSystem.Services;
using Microsoft.AspNetCore.Mvc;

namespace BankingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private AccountService _accountService;
        public AccountController(AccountService accountService)
        {
            _accountService = accountService;
        }


        [HttpGet]
        public IActionResult Get()
        {
            return Ok(new string[] { "dotnet-core-xunit-example", $"v{GetType().Assembly.GetName().Version.ToString()}", });
        }

        /// <summary>
        /// Get Account details
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetAccount(int id)
        {
            AccountDto.Account account = await _accountService.GetAccounts(id);

            if (account == null)
                return BadRequest("Account not found!");

            return Ok(account);
        }

        /// <summary>
        /// Add Account
        /// </summary>
        /// <param name="accountInfo"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> AddAccount([FromBody] AccountDto.Account accountInfo)
        {
            AccountDto.Account account = await _accountService.AddAccount(accountInfo);

            if (account == null)
                return BadRequest("Failed to add Account!");

            return Ok(account);
        }

        /// <summary>
        /// Withdraw Amount from Account
        /// </summary>
        /// <param name="id"></param>
        /// <param name="accountInfo"></param>
        /// <returns></returns>
        [Route("{id:int}")]
        [HttpPatch("{id}")]
        public async Task<IActionResult> WithdrawAmount(int id, [FromBody] AccountDto.Account accountInfo)
        {
            AccountDto.Account withdrawAmount = await _accountService.WithdrawAmount(id, accountInfo.AccountBalance);

            if (withdrawAmount == null)
                return BadRequest("Failed to Withdraw Amount!");

            return Ok(withdrawAmount);
        }

        /// <summary>
        /// Deposit Amount from Account
        /// </summary>
        /// <param name="id"></param>
        /// <param name="accountInfo"></param>
        /// <returns></returns>
        [Route("{id:int}")]
        [HttpPatch("{id}")]
        public async Task<IActionResult> DepositAmount(int id, [FromBody] AccountDto.Account accountInfo)
        {
            AccountDto.Account depositAmount = await _accountService.DepositAmount(id, accountInfo.AccountBalance);

            if (depositAmount == null)
                return BadRequest("Failed to Deposit Amount!");

            return Ok(depositAmount);
        }

        /// <summary>
        /// Delete Account
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            AccountDto.Account account = await _accountService.DeleteAccount(id);

            if (account == null)
                return BadRequest("Failed to delete Account!");

            return Ok(account);
        }
    }
}
