﻿namespace BankingSystem.Dtos
{
    /// <summary>
    /// Account Data Transfer Object.
    /// </summary>
    public class AccountDto
    {
        public class Account
        {
            public int Id { get; set; }
            public string Email { get; set; }
            public string Password { get; set; }
            public string FullName { get; set; }
            public DateTime LastLogin { get; set; }
            public DateTime CreateDate { get; set; }
            public bool Status { get; set; }
            public float AccountBalance { get; set; }
        }
    }

}
