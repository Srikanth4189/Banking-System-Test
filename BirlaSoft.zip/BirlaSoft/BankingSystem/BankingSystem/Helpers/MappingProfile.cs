﻿using AutoMapper;
using BankingSystem.Dtos;
using BankingSystem.Entities.TestDb;

namespace BankingSystem.Helpers
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Account, AccountDto.Account>();
            CreateMap<AccountDto.Account, Account>();
        }
    }
}
