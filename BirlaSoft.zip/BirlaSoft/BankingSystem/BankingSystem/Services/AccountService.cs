﻿using AutoMapper;
using BankingSystem.Dtos;
using BankingSystem.Entities.TestDb;
using BankingSystem.Services;

namespace BankingSystem.Services
{
    public class AccountService : IAccountService
    {

        private TestDbContext _testDbContext;

        private IMapper _mapper;

        public AccountService(TestDbContext testDbContext, IMapper mapper)
        {
            _testDbContext = testDbContext;
            _mapper = mapper;
        }

        public async Task<AccountDto.Account> AddAccount(AccountDto.Account account)
        {
            try
            {
                Account accounts = _mapper.Map<Account>(account);

                _testDbContext.Accounts.Add(accounts);
                _testDbContext.SaveChanges();

                return _mapper.Map<AccountDto.Account>(account);
            }
            catch (Exception exp)
            {
                return null;
            }
        }

        public async Task<AccountDto.Account> WithdrawAmount(int id, float amount)
        {
            try
            {
                Account accounts = _testDbContext.Accounts.Where(w => w.Id == id).FirstOrDefault();
                if (accounts == null)
                    return null;


                if (await CheckAccountBalanceLimit(accounts.AccountBalance) == true && await CheckIfWindrawAmountIsGreaterThan90Percent(amount))
                {
                    var newAmount = accounts.AccountBalance - amount;
                    if (newAmount < 0)
                    {
                        throw new Exception("Not Enought funds to proceed the transaction.");
                    }
                    accounts.AccountBalance = accounts.AccountBalance - amount;
                    _testDbContext.Accounts.Update(accounts);
                    _testDbContext.SaveChanges();
                }

                return _mapper.Map<AccountDto.Account>(accounts);
            }
            catch (Exception exp)
            {
                return null;
            }
        }

        public async Task<AccountDto.Account> DepositAmount(int id, float amount)
        {
            try
            {
                Account accounts = _testDbContext.Accounts.Where(w => w.Id == id).FirstOrDefault();
                if (accounts == null)
                    return null;

                if (await CheckAccountBalanceLimit(accounts.AccountBalance) == true && await CheckDepositLimit(amount))
                {
                    accounts.AccountBalance = accounts.AccountBalance + amount;
                    _testDbContext.Accounts.Update(accounts);
                    _testDbContext.SaveChanges();
                }


                return _mapper.Map<AccountDto.Account>(accounts);
            }
            catch (Exception exp)
            {
                return null;
            }
        }
        public async Task<AccountDto.Account> DeleteAccount(int id)
        {
            Account accounts = _testDbContext.Accounts.Where(w => w.Id == id).FirstOrDefault();

            if (accounts == null)
                return null;

            _testDbContext.Accounts.Remove(accounts);
            _testDbContext.SaveChanges();

            return _mapper.Map<AccountDto.Account>(accounts);
        }

        public async Task<AccountDto.Account> GetAccounts(int id)
        {
            Account accounts = _testDbContext.Accounts.Where(w => w.Id == id).FirstOrDefault();

            return _mapper.Map<AccountDto.Account>(accounts);
        }

        public async Task<bool> CheckAccountBalanceLimit(float balanceAmount)
        {
            bool result = false;
            try
            {
                if (balanceAmount <= 100)
                {
                    result = true;
                }

            }
            catch (Exception ex)
            {

            }
            return result;
        }
        public async Task<bool> CheckAccountBalanceLimitException(float balanceAmount)
        {
            if (balanceAmount <= 100)
            {
                throw new Exception("Not Enought funds to proceed the transaction.");
            }
            return false;

        }
        public async Task<bool> CheckIfWindrawAmountIsGreaterThan90Percent(float amount)
        {

            double result = ((double)amount / 100) * 90;

            return result > amount ? true : false;
        }

        public async Task<bool> CheckDepositLimit(float amount)
        {
            return amount > 10000 ? true : false;
        }

    }
}
