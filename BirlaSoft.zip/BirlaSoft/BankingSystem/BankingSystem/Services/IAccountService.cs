﻿using BankingSystem.Dtos;

namespace BankingSystem.Services
{
    /// <summary>
    /// Account Service
    /// </summary>
    public interface IAccountService
    {
        Task<AccountDto.Account> GetAccounts(int id);

        Task<AccountDto.Account> AddAccount(AccountDto.Account account);

        Task<AccountDto.Account> DeleteAccount(int id);
        Task<AccountDto.Account> WithdrawAmount(int id, float amount);
        Task<AccountDto.Account> DepositAmount(int id, float account);

        Task<bool> CheckAccountBalanceLimit(float balanceAmount);
        Task<bool> CheckAccountBalanceLimitException(float balanceAmount);

        Task<bool> CheckIfWindrawAmountIsGreaterThan90Percent(float balanceAmount);

        Task<bool> CheckDepositLimit(float balanceAmount);
    }
}
