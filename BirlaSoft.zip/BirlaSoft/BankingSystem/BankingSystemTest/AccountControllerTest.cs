﻿using BankingSystem.Controllers;
using BankingSystem.Dtos;
using BankingSystem.Services;
using BankingSystemTest.Fixture;
using BankingSystemTest.Theory;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Xunit;

namespace BankingSystemTest
{

    public class AccountControllerTest : IClassFixture<ControllerFixture>
    {
        AccountController accountController;


        /**
         * xUnit constructor runs before each test. 
         */
        public AccountControllerTest(ControllerFixture fixture)
        {
            accountController = fixture.accountController;
        }

        /// <summary>
        /// Checking string length test
        /// </summary>
        [Fact]
        public void Get_WithoutParam_Ok_Test()
        {
            var result = accountController.Get() as OkObjectResult;

            Assert.Equal(200, result.StatusCode);
            Assert.True((result.Value as string[]).Length == 2);
        }

        /// <summary>
        /// Bad request for checking Account Id
        /// </summary>
        /// <param name="id"></param>
        [Theory]
        [InlineData(0)]
        public async void GetUser_WithNonUser_ThenBadRequest_Test(int id)
        {
            var result = await accountController.GetAccount(id) as BadRequestObjectResult;

            Assert.Equal(400, result.StatusCode);
            Assert.Equal("Account not found!", result.Value);
        }

        /// <summary>
        /// Positive test case for getting account details
        /// </summary>
        /// <param name="id"></param>
        [Theory]
        [InlineData(454673)]
        public async void GetUser_WithTestData_ThenOk_Test(int id)
        {
            var result = await accountController.GetAccount(id) as OkObjectResult;

            Assert.Equal(200, result.StatusCode);
            Assert.IsType<AccountDto.Account>(result.Value);
        }

        /// <summary>
        /// Positive test case for adding account details
        /// </summary>
        /// <param name="userInfo"></param>
        [Theory]
        [ClassData(typeof(AccountTheoryData))]
        public async void AddUser_WithTestData_ThenOk_Test(AccountDto.Account userInfo)
        {
            var result = await accountController.AddAccount(userInfo) as OkObjectResult;

            Assert.Equal(200, result.StatusCode);
            Assert.Equal(JsonConvert.SerializeObject(userInfo), JsonConvert.SerializeObject(result.Value));
        }

        /// <summary>
        ///  Successful test case to Withdraw Amount from account
        /// </summary>
        /// <param name="userInfo"></param>
        [Theory]
        [ClassData(typeof(AccountTheoryData))]
        public async void WithdrawAmount_WithTestData_ThenOk_Test(AccountDto.Account userInfo)
        {
            var result = await accountController.WithdrawAmount(685349, userInfo) as OkObjectResult;

            Assert.Equal(200, result.StatusCode);
            Assert.IsType<AccountDto.Account>(result.Value);
        }

        /// <summary>
        /// Positive test case to Deposit Amount to account
        /// </summary>
        /// <param name="userInfo"></param>
        [Theory]
        [ClassData(typeof(AccountTheoryData))]
        public async void DepositAmount_WithTestData_ThenOk_Test(AccountDto.Account userInfo)
        {
            var result = await accountController.DepositAmount(6853, userInfo) as OkObjectResult;

            Assert.Equal(200, result.StatusCode);
            Assert.IsType<AccountDto.Account>(result.Value);
        }

        /// <summary>
        /// Exception test case for deleting account
        /// </summary>
        /// <param name="id"></param>
        [Theory]
        [InlineData(0)]
        public async void Delete_WithNonUser_ThenBadRequest_Test(int id)
        {
            var result = await accountController.Delete(id) as BadRequestObjectResult;

            Assert.Equal(400, result.StatusCode);
            Assert.Equal("Failed to delete Account!", result.Value);
        }

        /// <summary>
        /// Positive test case for deleting account
        /// </summary>
        /// <param name="id"></param>
        [Theory]
        [InlineData(685349)]
        public async void Delete_WithTestData_ThenOk_Test(int id)
        {
            var result = await accountController.Delete(id) as OkObjectResult;

            Assert.Equal(200, result.StatusCode);
            Assert.IsType<AccountDto.Account>(result.Value);
        }
    }
}
