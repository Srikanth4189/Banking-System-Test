﻿using BankingSystem.Controllers;
using BankingSystem.Dtos;
using BankingSystem.Services;
using BankingSystemTest.Fixture;
using BankingSystemTest.Theory;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Storage;
using Newtonsoft.Json;
using Xunit;

namespace BankingSystemTest
{
    public class AccountServiceTest : IClassFixture<AccountServiceFixture>
    {
        private AccountService _accountService;
        /**
 * xUnit constructor runs before each test. 
 */
        public AccountServiceTest(AccountServiceFixture fixture)
        {
            _accountService = fixture.accountService;
        }

        /// <summary>
        /// Positive test case for checking account balance
        /// </summary>
        /// <param name="amount"></param>
        [Theory]
        [InlineData(1000)]
        public async void AccountBalanceLimit_WithTestData_ThenOk_Test(float amount)
        {
            var ExpectedValue = false;
            var result = await _accountService.CheckAccountBalanceLimit(amount);

            Assert.Equal(ExpectedValue, result);
        }

        /// <summary>
        /// Negative test senario to check account balance
        /// </summary>
        /// <param name="amount"></param>
        /// <returns></returns>
        [Theory]
        [InlineData(1000)]
        public async Task AccountBalanceLimit_WithNonUser_ThenBadRequest_Test(float amount)
        {
            var ExpectedValue = false;
            var result = await _accountService.CheckAccountBalanceLimit(amount);

            Assert.Equal(ExpectedValue, result);
        }

        /// <summary>
        /// Exception test case for checking account balance
        /// </summary>
        /// <param name="amount"></param>
        [Theory]
        [InlineData(0)]
        public async void GivenUserAttemptWithdrawal_WhenNotEnoughFundsAreInTheAccount_ShouldThrowException(float amount)
        {
            var exceptionResult = await Assert.ThrowsAsync<Exception>(() => _accountService.CheckAccountBalanceLimitException(amount));
            Assert.Equal("Not Enought funds to proceed the transaction.", exceptionResult.Message);
        }

        /// <summary>
        /// Positive test case for checking If WindrawAmount Is Greater Than 90 Percent
        /// </summary>
        /// <param name="amount"></param>
        [Theory]
        [InlineData(1000)]
        public async void CheckIfWindrawAmountIsGreaterThan90Percent_WithTestData_ThenOk_Test(float amount)
        {
            var ExpectedValue = false;
            var result = await _accountService.CheckIfWindrawAmountIsGreaterThan90Percent(amount);

            Assert.Equal(ExpectedValue, result);
        }

    }
}
