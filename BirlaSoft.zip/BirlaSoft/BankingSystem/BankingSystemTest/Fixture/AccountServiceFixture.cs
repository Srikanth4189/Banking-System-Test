﻿using AutoMapper;
using BankingSystem.Controllers;
using BankingSystem.Helpers;
using BankingSystem.Services;
using BankingSystemTest.Mock.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystemTest.Fixture
{
    public class AccountServiceFixture : IDisposable
    {

        private TestDbContextMock testDbContextMock { get; set; }
        public AccountService accountService { get; set; }
        private IMapper mapper { get; set; }


        public AccountServiceFixture()
        {
            #region Create mock/memory database

            testDbContextMock = new TestDbContextMock();

            testDbContextMock.Accounts.AddRange(new BankingSystem.Entities.TestDb.Account[]
            {
                // for delete test
                new BankingSystem.Entities.TestDb.Account()
                {
                  Id = 685349,
                  Email = "0sgtsw",
                  Password = "jmctby",
                  FullName = "mq8zp2",
                  CreateDate = DateTime.Now,
                  Status = true,
                  AccountBalance  = 500000
                },
                new BankingSystem.Entities.TestDb.Account()
                {
                  Id = 6853,
                  Email = "0sgtsw",
                  Password = "jmctby",
                  FullName = "mq8zp2",
                  CreateDate = DateTime.Now,
                  Status = true,
                  AccountBalance  = 500
                },
                // for get test
                new BankingSystem.Entities.TestDb.Account()
                {
                  Id = 454673,
                  Email = "0tec4e",
                  Password = "al9jje",
                  FullName = "jqvlv2",
                  CreateDate = DateTime.Now,
                  Status = true,
                  AccountBalance  = 500000
                }
            });

            testDbContextMock.SaveChanges();

            #endregion

            #region Mapper settings with original profiles.

            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new MappingProfile());
            });

            mapper = mappingConfig.CreateMapper();

            #endregion

            // Create AccountService with Memory Database
            accountService = new AccountService(testDbContextMock, mapper);


        }

        #region ImplementIDisposableCorrectly

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // NOTE: Leave out the finalizer altogether if this class doesn't
        // own unmanaged resources, but leave the other methods
        // exactly as they are.
        ~AccountServiceFixture()
        {
            // Finalizer calls Dispose(false)
            Dispose(false);
        }

        // The bulk of the clean-up code is implemented in Dispose(bool)
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                testDbContextMock.Dispose();
                testDbContextMock = null;

                accountService = null;
                mapper = null;

            }
        }
        #endregion
    }
}
