﻿using BankingSystem.Dtos;
using System;
using Xunit;


namespace BankingSystemTest.Theory
{
    public class AccountTheoryData : TheoryData<AccountDto.Account>
    {
        public AccountTheoryData()
        {
            /**
             * Each item you add to the TheoryData collection will try to pass your unit test's one by one.
             */

            // mock data created to add to Account
            Add(new AccountDto.Account()
            {
                Email = "yft97l",
                CreateDate = DateTime.Now,
                FullName = "8s0quo",
                Id = 210544,
                Password = "d87btl",
                LastLogin = DateTime.Now,
                Status = true,
                AccountBalance = 50000,
            });
        }
    }
}
